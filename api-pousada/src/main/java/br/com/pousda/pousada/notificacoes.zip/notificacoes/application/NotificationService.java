package br.com.pousda.pousada.notificacoes.application;


import br.com.pousda.pousada.notificacoes.core.domain.enums.*;
import br.com.pousda.pousada.notificacoes.core.domain.model.Notification;
import br.com.pousda.pousada.notificacoes.core.infra.repo.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository repo;
    private final NotificationPublisher publisher;

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm").withZone(SP);
    private static final long TTL_SECONDS = 90 * 60; // 90 minutos

    public Notification send(
            NotificationType type,
            String title,
            String body,
            String link,
            String action,
            Long itemId,
            String dateText,
            Long autorId,
            String autorJson,
            NotificationOrigin origin,
            Set<Long> recipients
    ) {
        var now = Instant.now();
        var n = new Notification();
        n.setType(type);
        n.setTitle(title);
        n.setBody(body);
        n.setLink(link);
        n.setAction(action);
        n.setItemId(itemId);
        n.setDate(dateText != null ? dateText : DTF.format(now));
        n.setOrigin(origin);
        n.setStatus(NotificationStatus.NOVO);
        n.setRecipients(recipients);
        n.setAutorId(autorId);
        n.setAutorJson(autorJson);
        n.setCreatedAt(now);
        n.setExpiresAt(now.plusSeconds(TTL_SECONDS));

        var saved = repo.save(n);
        publisher.publish(saved);
        return saved;
    }
}
