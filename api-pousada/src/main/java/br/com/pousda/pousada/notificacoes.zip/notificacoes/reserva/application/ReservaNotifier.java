package br.com.pousda.pousada.notificacoes.reserva.application;

import java.util.Set;

public interface ReservaNotifier {
    void criada(Long reservaId, String codigo, String hospede, String quarto,
                Long autorId, String autorJson, Set<Long> destinatarios);

    void atualizada(Long reservaId, String codigo, String campo, String de, String para,
                    Long autorId, String autorJson, Set<Long> destinatarios);

    void confirmada(Long reservaId, String codigo, String hospede,
                    Long autorId, String autorJson, Set<Long> destinatarios);

    void cancelada(Long reservaId, String codigo, String motivo,
                   Long autorId, String autorJson, Set<Long> destinatarios);

    void resumoVespera(int qtd, Set<Long> destinatarios);
    void hojePendente(int qtd, Set<Long> destinatarios);
    void ultimaChamada(Long reservaId, String codigo, String hospede, String quarto, Set<Long> destinatarios);
    void naoConfirmadaCancelada(Long reservaId, String codigo, String hospede, Set<Long> destinatarios);
}
