package br.com.pousda.pousada.notificacoes.core.infra.repo;


import br.com.pousda.pousada.notificacoes.core.domain.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.Collection;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    long deleteByExpiresAtBefore(Instant now);

    List<Notification> findByRecipientsInAndExpiresAtAfterOrderByCreatedAtDesc(
            Collection<Long> recipients, Instant now
    );
}
