package br.com.pousda.pousada.notificacoes.financeiro.application;


import br.com.pousda.pousada.notificacoes.application.NotificationService;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationOrigin;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class FinanceiroNotifierImpl implements FinanceiroNotifier {

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private final NotificationService notifications;

    private String today() { return LocalDate.now(SP).toString(); }

    @Override
    public void saidaCriada(Long saidaId, String motivo, Double valor,
                            Long autorId, String autorJson, Set<Long> destinatarios) {
        String body = String.format("Saída criada • %s • R$ %.2f", safe(motivo), valor != null ? valor : 0d);
        notifications.send(
                NotificationType.FIN_SAIDA_CRIADA,
                "Financeiro: saída criada",
                body,
                "/financeiro/saidas/" + saidaId,
                "VER_SAIDA",
                saidaId,
                today(),
                autorId, autorJson,
                NotificationOrigin.USUARIO,
                destinatarios
        );
    }

    @Override
    public void saidaAtualizada(Long saidaId, String deMotivo, Double deValor,
                                String paraMotivo, Double paraValor,
                                Long autorId, String autorJson, Set<Long> destinatarios) {
        String body = String.format(
                "Saída atualizada • motivo: %s → %s • valor: R$ %.2f → R$ %.2f",
                safe(deMotivo), safe(paraMotivo),
                deValor != null ? deValor : 0d,
                paraValor != null ? paraValor : 0d
        );
        notifications.send(
                NotificationType.FIN_SAIDA_ATUALIZADA,
                "Financeiro: saída atualizada",
                body,
                "/financeiro/saidas/" + saidaId,
                "VER_SAIDA",
                saidaId,
                today(),
                autorId, autorJson,
                NotificationOrigin.USUARIO,
                destinatarios
        );
    }

    @Override
    public void saidaExcluida(Long saidaId, String motivo, Double valor,
                              Long autorId, String autorJson, Set<Long> destinatarios) {
        String body = String.format("Saída excluída • %s • R$ %.2f", safe(motivo), valor != null ? valor : 0d);
        notifications.send(
                NotificationType.FIN_SAIDA_EXCLUIDA,
                "Financeiro: saída excluída",
                body,
                "/financeiro/saidas", // lista
                "VER_SAIDAS",
                saidaId,
                today(),
                autorId, autorJson,
                NotificationOrigin.USUARIO,
                destinatarios
        );
    }

    private String safe(String s) { return s == null ? "-" : s; }
}
