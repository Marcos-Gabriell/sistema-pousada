package br.com.pousda.pousada.notificacoes.infra.repo;


import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationStatus;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationType;
import br.com.pousda.pousada.notificacoes.core.domain.model.Notification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    int countByDestinatarioIdAndStatus(Long destinatarioId, NotificationStatus status);

    Page<Notification> findByDestinatarioId(Long destinatarioId, Pageable pageable);

    Page<Notification> findByDestinatarioIdAndStatus(
            Long destinatarioId,
            NotificationStatus status,
            Pageable pageable
    );

    Optional<Notification> findByIdAndDestinatarioId(Long id, Long destinatarioId);

    boolean existsByDedupKey(String dedupKey);
    boolean existsByDestinatarioIdAndDedupKey(Long destinatarioId, String dedupKey);

    boolean existsByTipoAndReferenciaIdAndDestinatarioIdAndDataReferencia(
            NotificationType tipo, Long referenciaId, Long destinatarioId, Long dataRef);

    List<Notification> findByDestinatarioIdAndStatusAndCriadaEmAfter(
            Long destinatarioId, NotificationStatus status, LocalDateTime after);

    @Query(
            "SELECT n FROM Notification n " +
                    "WHERE n.destinatarioId = :uid " +
                    "  AND (:status IS NULL OR n.status = :status) " +
                    "  AND (LOWER(n.titulo) LIKE LOWER(CONCAT('%', :q, '%')) " +
                    "       OR LOWER(n.mensagem) LIKE LOWER(CONCAT('%', :q, '%')))"
    )
    Page<Notification> search(@Param("uid") long uid,
                              @Param("status") NotificationStatus status,
                              @Param("q") String q,
                              Pageable pageable);
}
