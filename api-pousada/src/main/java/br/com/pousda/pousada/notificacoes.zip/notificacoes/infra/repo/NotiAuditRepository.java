package br.com.pousda.pousada.notificacoes.infra.repo;


import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.Optional;

public interface NotiAuditRepository extends JpaRepository<NotiAuditRepository, Long> {
    Optional<NotiAuditRepository> findByTypeAndRefIdAndRefDate(String type, Long refId, LocalDate refDate);
}
