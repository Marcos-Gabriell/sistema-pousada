package br.com.pousda.pousada.notificacoes.core.domain.model;

import br.com.pousda.pousada.notificacoes.core.domain.enums.*;
import javax.persistence.*;
import java.time.Instant;
import java.util.Set;

@Entity
@Table(name = "notifications", indexes = {
        @Index(name = "idx_notifications_expires_at", columnList = "expiresAt"),
        @Index(name = "idx_notifications_status", columnList = "status")
})
public class Notification {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 48)
    private NotificationType type;

    @Column(nullable = false, length = 140)
    private String title;

    @Lob @Column(nullable = false)
    private String body;

    private String link;
    private String action;
    private Long itemId;
    private String date;

    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 24)
    private NotificationOrigin origin;

    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 24)
    private NotificationStatus status = NotificationStatus.NOVO;

    // ids dos destinatários
    @ElementCollection
    @CollectionTable(name = "notification_recipients", joinColumns = @JoinColumn(name = "notification_id"))
    @Column(name = "user_id")
    private Set<Long> recipients;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant expiresAt; // TTL

    private Long autorId;
    private String autorJson;

    @PrePersist
    public void onCreate() {
        if (createdAt == null) createdAt = Instant.now();
        if (expiresAt == null) expiresAt = createdAt.plusSeconds(90 * 60); // 90 min
    }

    // getters/setters (pode gerar com Lombok se quiser)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public NotificationType getType() { return type; }
    public void setType(NotificationType type) { this.type = type; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public Long getItemId() { return itemId; }
    public void setItemId(Long itemId) { this.itemId = itemId; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public NotificationOrigin getOrigin() { return origin; }
    public void setOrigin(NotificationOrigin origin) { this.origin = origin; }
    public NotificationStatus getStatus() { return status; }
    public void setStatus(NotificationStatus status) { this.status = status; }
    public Set<Long> getRecipients() { return recipients; }
    public void setRecipients(Set<Long> recipients) { this.recipients = recipients; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getExpiresAt() { return expiresAt; }
    public void setExpiresAt(Instant expiresAt) { this.expiresAt = expiresAt; }
    public Long getAutorId() { return autorId; }
    public void setAutorId(Long autorId) { this.autorId = autorId; }
    public String getAutorJson() { return autorJson; }
    public void setAutorJson(String autorJson) { this.autorJson = autorJson; }
}
