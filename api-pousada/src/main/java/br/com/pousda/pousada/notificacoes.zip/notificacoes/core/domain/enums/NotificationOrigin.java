package br.com.pousda.pousada.notificacoes.core.domain.enums;

public enum NotificationOrigin { USUARIO, AUTOMATICO }
