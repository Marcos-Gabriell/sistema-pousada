package br.com.pousda.pousada.notificacoes.application.facade;

import br.com.pousda.pousada.hospedagens.domain.Hospedagem;
import br.com.pousda.pousada.notificacoes.financeiro.application.FinanceiroNotifier;
import br.com.pousda.pousada.notificacoes.hospedagem.application.HospedagemNotifier;
import br.com.pousda.pousada.notificacoes.quarto.application.QuartoNotifier;
import br.com.pousda.pousada.notificacoes.reserva.application.ReservaNotifier;
import br.com.pousda.pousada.notificacoes.usuarios.application.UsuarioNotifier;
import br.com.pousda.pousada.quartos.domain.Quarto;
import br.com.pousda.pousada.quartos.dtos.QuartoChangeSet;
import br.com.pousda.pousada.reservas.domain.Reserva;
import br.com.pousda.pousada.usuarios.domain.Usuario;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
@RequiredArgsConstructor
public class NotifierFacade {

    private final ReservaNotifier reservaNotifier;
    private final HospedagemNotifier hospedagemNotifier;
    private final UsuarioNotifier usuarioNotifier;
    private final FinanceiroNotifier financeiroNotifier;
    private final QuartoNotifier quartoNotifier;

    /* ======================= RESERVA ======================= */
    public void reservaCriada(Reserva r) { /* ... igual à versão anterior ... */
        reservaNotifier.criada(
                r.getId(), safe(r.getCodigo()), safe(r.getNome()),
                r.getQuarto() != null ? safe(r.getQuarto().getNumero()) : "-",
                null, null, destinatariosPadrao()
        );
    }
    public void reservaAtualizada(Reserva before, Reserva after) { /* ... */
        reservaNotifier.atualizada(
                after.getId(), safe(after.getCodigo()),
                "dados", "-", "-",
                null, null, destinatariosPadrao()
        );
    }
    public void reservaAtualizada(Reserva r) { /* ... */
        reservaNotifier.atualizada(
                r.getId(), safe(r.getCodigo()),
                "dados", "-", "-",
                null, null, destinatariosPadrao()
        );
    }
    public void reservaCancelada(Reserva r) { /* ... */
        reservaNotifier.cancelada(
                r.getId(), safe(r.getCodigo()),
                "Cancelada", null, null, destinatariosPadrao()
        );
    }
    public void reservaConfirmada(Reserva r) { /* ... */
        reservaNotifier.confirmada(
                r.getId(), safe(r.getCodigo()), safe(r.getNome()),
                null, null, destinatariosPadrao()
        );
    }

    /* ===================== HOSPEDAGEM ====================== */
    public void hospedagemCriada(Hospedagem h) { /* ... igual ... */
        hospedagemNotifier.criada(
                h.getId(), safe(h.getNome()),
                h.getQuarto() != null ? safe(h.getQuarto().getNumero()) : "-",
                safeDate(h.getDataEntrada()), safeDate(h.getDataSaida()),
                null, null, destinatariosPadrao()
        );
    }
    public void hospedagemAtualizada(Hospedagem h, String resumo) { /* ... */
        hospedagemNotifier.atualizada(
                h.getId(), safe(h.getNome()),
                "resumo", "-", safe(resumo),
                null, null, destinatariosPadrao()
        );
    }
    public void hospedagemCheckoutAutomaticoConcluido(Hospedagem h) { /* ... */
        hospedagemNotifier.atualizada(
                h.getId(), safe(h.getNome()),
                "checkout", "-", "Checkout automático concluído",
                null, null, destinatariosPadrao()
        );
    }

    /* ======================== USUÁRIO ======================= */
    public void usuarioCriado(Usuario u) { /* ... igual ... */
        usuarioNotifier.criado(
                u.getId(), safe(u.getNome()), safe(u.getEmail()),
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioAtualizado(Usuario u, String campo, String de, String para) { /* ... */
        usuarioNotifier.atualizado(
                u.getId(), safe(u.getNome()), safe(campo), safe(de), safe(para),
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioStatusAlterado(Usuario u, String novoStatus) { /* ... */
        usuarioNotifier.statusAlterado(
                u.getId(), safe(u.getNome()), safe(novoStatus),
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioSenhaResetada(Usuario u) { /* ... */
        usuarioNotifier.senhaResetada(
                u.getId(), safe(u.getNome()),
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioAutoExcluido(Usuario u, String motivo) { /* ... */
        usuarioNotifier.autoExcluido(
                u.getId(), safe(u.getNome()),
                destinatariosPadrao()
        );
    }
    public void usuarioExcluido(Usuario u) { /* ... */
        usuarioNotifier.excluido(
                u.getId(), safe(u.getNome()),
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioAtualizouProprioPerfil(Usuario u, String campo, String de, String para) { /* ... */
        usuarioNotifier.atualizouProprioPerfil(
                u.getId(), safe(u.getNome()), safe(campo), safe(de), safe(para),
                destinatariosPadrao()
        );
    }
    public void usuarioSenhaAtualizadaPeloProprio(Usuario u) { /* ... */
        usuarioNotifier.senhaAtualizadaPeloProprio(
                u.getId(), safe(u.getNome()),
                destinatariosPadrao()
        );
    }
    // Sobrecargas compatíveis com seu UsuarioService
    public void usuarioCriado(Usuario criador, Usuario u) { usuarioCriado(u); }
    public void usuarioAtualizado(Usuario ator, Usuario salvo, String msgResumo) {
        usuarioNotifier.atualizado(
                salvo.getId(), safe(salvo.getNome()),
                "resumo", "-", safe(msgResumo),
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioStatusAlterado(Usuario ator, Usuario alvo, boolean novoAtivo, String motivo) {
        usuarioNotifier.statusAlterado(
                alvo.getId(), safe(alvo.getNome()),
                novoAtivo ? "ATIVO" : "INATIVO",
                null, null, destinatariosPadrao()
        );
    }
    public void usuarioSenhaResetada(Usuario ator, Usuario alvo) { usuarioSenhaResetada(alvo); }

    /* ======================= FINANCEIRO ===================== */
    public void finSaidaCriada(Long id, String motivo, Double valor) {
        financeiroNotifier.saidaCriada(id, motivo, valor, null, null, destinatariosAdmin());
    }
    public void finSaidaAtualizada(Long id, String deMotivo, Double deValor, String paraMotivo, Double paraValor) {
        financeiroNotifier.saidaAtualizada(id, deMotivo, deValor, paraMotivo, paraValor, null, null, destinatariosAdmin());
    }
    public void finSaidaExcluida(Long id, String motivo, Double valor) {
        financeiroNotifier.saidaExcluida(id, motivo, valor, null, null, destinatariosAdmin());
    }

    /* ========================= QUARTO ======================= */
    public void quartoCriado(Quarto q) {
        quartoNotifier.criado(q, null, null, destinatariosPadrao());
    }
    public void quartoAtualizado(Quarto q, QuartoChangeSet changeSet) {
        String resumo = (changeSet == null) ? "dados" : changeSet.toString();
        quartoNotifier.atualizado(q, resumo, null, null, destinatariosPadrao());
    }
    public void quartoEntrouManutencao(Quarto q) {
        quartoNotifier.entrouManutencao(q, null, null, destinatariosPadrao());
    }
    public void quartoVoltouDisponivel(Quarto q) {
        quartoNotifier.voltouDisponivel(q, null, null, destinatariosPadrao());
    }
    public void quartoExcluido(Quarto q) {
        quartoNotifier.excluido(q, null, null, destinatariosPadrao());
    }

    /* ========================== Helpers ===================== */
    private Set<Long> destinatariosPadrao() {
        // ajuste conforme sua regra (ex.: recepção)
        return Set.of();
    }
    private Set<Long> destinatariosAdmin() {
        // ajuste para admins (pode integrar com UsersQueryPort se quiser)
        return Set.of();
    }
    private String safe(String s) { return s == null ? "-" : s; }
    private String safeDate(java.time.LocalDate d) { return d == null ? "-" : d.toString(); }
}
