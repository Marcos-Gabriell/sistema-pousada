package br.com.pousda.pousada.notificacoes.api;

import br.com.pousda.pousada.notificacoes.application.NotificationPushService;
import br.com.pousda.pousada.notificacoes.application.UsersQueryPort;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationStatus;
import br.com.pousda.pousada.notificacoes.core.domain.model.Notification;
import br.com.pousda.pousada.notificacoes.core.infra.repo.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/notificacoes")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class NotificationController {

    private final NotificationRepository repo;
    private final UsersQueryPort users;
    private final NotificationPushService push;

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseEntity<SseEmitter> stream() {
        long uid = users.currentUserId();
        if (uid == 0L) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(push.subscribe(uid));
    }

    @GetMapping("/unread-count")
    public Map<String, Integer> unreadCount() {
        long uid = users.currentUserId();
        if (uid == 0L) return Map.of("count", 0);
        var now = Instant.now();
        var ativas = repo.findByRecipientsInAndExpiresAtAfterOrderByCreatedAtDesc(Set.of(uid), now);
        int count = (int) ativas.stream().filter(n -> n.getStatus() == NotificationStatus.NOVO).count();
        return Map.of("count", count);
    }

    @GetMapping
    public ResponseEntity<?> listar(@RequestParam(required = false) String status,
                                    @RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "20") int size,
                                    @RequestParam(required = false) String q) {
        long uid = users.currentUserId();
        if (uid == 0L) {
            return ResponseEntity.status(401).body(Map.of("error", "Usuário não autenticado"));
        }

        NotificationStatus st = null;
        try {
            if (status != null && !status.trim().isEmpty()) {
                st = NotificationStatus.valueOf(status.trim().toUpperCase(Locale.ROOT));
            }
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("error", "Status inválido: " + status));
        }

        var now = Instant.now();
        List<Notification> list = repo.findByRecipientsInAndExpiresAtAfterOrderByCreatedAtDesc(Set.of(uid), now);

        // Fix: cópias finais para uso nas lambdas
        final NotificationStatus stFilter = st;

        if (stFilter != null) {
            list = list.stream()
                    .filter(n -> n.getStatus() == stFilter)
                    .collect(Collectors.toList());
        }

        final String qFilter = (q == null) ? "" : q.trim().toLowerCase(Locale.ROOT);
        if (!qFilter.isEmpty()) {
            list = list.stream()
                    .filter(n -> containsIgnoreCase(n.getTitle(), qFilter) || containsIgnoreCase(n.getBody(), qFilter))
                    .collect(Collectors.toList());
        }

        int from = Math.max(0, page * size);
        int to = Math.min(list.size(), from + size);
        if (from >= to) return ResponseEntity.ok(Collections.emptyList());
        return ResponseEntity.ok(list.subList(from, to));
    }

    private boolean containsIgnoreCase(String s, String q) {
        return s != null && s.toLowerCase(Locale.ROOT).contains(q);
    }

    @PatchMapping("/{id}/lida")
    @Transactional
    public ResponseEntity<Void> lida(@PathVariable Long id) {
        long uid = users.currentUserId();
        var opt = repo.findById(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        Notification n = opt.get();
        if (n.getRecipients() == null || !n.getRecipients().contains(uid)) {
            return ResponseEntity.status(404).build();
        }

        if (n.getStatus() != NotificationStatus.LIDO) {
            n.setStatus(NotificationStatus.LIDO);
            repo.save(n);
        }
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/marcar-todas-como-lidas")
    @Transactional
    public ResponseEntity<Void> marcarTodas() {
        long uid = users.currentUserId();
        var now = Instant.now();
        var ativas = repo.findByRecipientsInAndExpiresAtAfterOrderByCreatedAtDesc(Set.of(uid), now);

        boolean mudou = false;
        for (var n : ativas) {
            if (n.getStatus() == NotificationStatus.NOVO) {
                n.setStatus(NotificationStatus.LIDO);
                mudou = true;
            }
        }
        if (mudou) repo.saveAll(ativas);
        return ResponseEntity.noContent().build();
    }
}
