package br.com.pousda.pousada.notificacoes.core.infra.jobs;


import br.com.pousda.pousada.notificacoes.core.infra.repo.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;

@Slf4j
@Component
@RequiredArgsConstructor
public class NotificationCleanupJob {

    private final NotificationRepository repo;

    // roda a cada 5 minutos
    @Scheduled(cron = "0 */5 * * * *", zone = "America/Sao_Paulo")
    public void removeExpiradas() {
        long apagadas = repo.deleteByExpiresAtBefore(Instant.now());
        if (apagadas > 0) log.info("[TTL] Notificações expiradas removidas: {}", apagadas);
    }
}
