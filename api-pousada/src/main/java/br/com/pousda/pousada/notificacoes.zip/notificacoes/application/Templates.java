package br.com.pousda.pousada.notificacoes.application;


import org.springframework.stereotype.Component;

@Component
public class Templates {

    /* ===== RESERVA ===== */
    public String reservaCriada(String codigo, String hospede, String quarto) {
        return String.format("Reserva %s criada para %s — Quarto %s", codigo, hospede, quarto);
    }
    public String reservaAtualizada(String codigo, String campo, String de, String para) {
        return String.format("Reserva %s atualizada: %s (%s → %s)", codigo, campo, de, para);
    }
    public String reservaConfirmada(String codigo, String hospede) {
        return String.format("Reserva %s confirmada para %s", codigo, hospede);
    }
    public String reservaCancelada(String codigo, String motivo) {
        return String.format("Reserva %s cancelada. Motivo: %s", codigo, motivo);
    }
    public String reservaResumoVespera(int qtd) {
        return String.format("Há %d reservas com check-in AMANHÃ.", qtd);
    }
    public String reservaHojePendente(int qtd) {
        return String.format("Existem %d reservas com check-in HOJE pendentes de confirmação.", qtd);
    }
    public String reservaUltimaChamada(String codigo, String hospede, String quarto) {
        return String.format("Reserva %s — %s (Quarto %s). Última chamada para confirmar.", codigo, hospede, quarto);
    }
    public String reservaNaoConfirmadaCancelada(String codigo, String hospede) {
        return String.format("Reserva %s (%s) cancelada automaticamente por falta de confirmação.", codigo, hospede);
    }

    /* ===== HOSPEDAGEM ===== */
    public String hospedagemCriada(String hospede, String quarto, String checkin, String checkout) {
        return String.format("Hospedagem criada para %s — Quarto %s (%s → %s)", hospede, quarto, checkin, checkout);
    }
    public String hospedagemAtualizada(String hospede, String campo, String de, String para) {
        return String.format("Hospedagem de %s atualizada: %s (%s → %s)", hospede, campo, de, para);
    }
    public String hospedagemCheckout11h(String quarto, String hospede) {
        return String.format("Quarto %s — %s. Lembrete de checkout às 11h.", quarto, hospede);
    }
    public String hospedagemAlertaReservaAmanha(String hospede, String quarto) {
        return String.format("Amanhã: %s — Quarto %s", hospede, quarto);
    }

    /* ===== QUARTO ===== */
    public String quartoEntrouManutencao(String numero, String motivo) {
        return String.format("Quarto %s entrou em manutenção. Motivo: %s", numero, motivo);
    }
    public String quartoSeteDiasManutencao(String numero) {
        return String.format("Quarto %s está em manutenção há 7 dias.", numero);
    }
    public String quartoVoltouDisponivel(String numero) {
        return String.format("Quarto %s voltou a ficar disponível.", numero);
    }
    public String quartoCriado(String numero, String tipo) {
        return String.format("Quarto %s criado (%s).", numero, tipo);
    }
    public String quartoAtualizado(String numero, String campo, String de, String para) {
        return String.format("Quarto %s atualizado: %s (%s → %s)", numero, campo, de, para);
    }
    public String quartoExcluido(String numero) {
        return String.format("Quarto %s foi excluído.", numero);
    }

    /* ===== FINANCEIRO (SAÍDAS) ===== */
    public String saidaCriada(String categoria, String descricao, String valor) {
        return String.format("Saída %s: %s — R$ %s", categoria, descricao, valor);
    }
    public String saidaAtualizada(Long id, String campo, String de, String para) {
        return String.format("Saída %d atualizada: %s (%s → %s)", id, campo, de, para);
    }
    public String saidaExcluida(Long id, String descricao) {
        return String.format("Saída %d (%s) foi excluída.", id, descricao);
    }

    /* ===== USUÁRIO ===== */
    public String usuarioCriado(String nome, String email) {
        return String.format("Usuário %s (%s) foi criado.", nome, email);
    }
    public String usuarioAtualizado(String nome, String campo, String de, String para) {
        return String.format("Usuário %s atualizado: %s (%s → %s)", nome, campo, de, para);
    }
    public String usuarioStatusAlterado(String nome, String novoStatus) {
        return String.format("Usuário %s agora está %s.", nome, novoStatus);
    }
    public String usuarioSenhaResetada(String nome) {
        return String.format("Senha do usuário %s foi resetada.", nome);
    }
    public String usuarioAutoExcluido(String nome) {
        return String.format("Usuário %s solicitou autoexclusão e foi removido.", nome);
    }
    public String usuarioExcluido(String nome) {
        return String.format("Usuário %s foi excluído.", nome);
    }
    public String usuarioAtualizouProprioPerfil(String nome, String campo, String de, String para) {
        return String.format("%s atualizou o próprio perfil: %s (%s → %s)", nome, campo, de, para);
    }
    public String usuarioSenhaAtualizadaPeloProprio(String nome) {
        return String.format("%s atualizou a própria senha.", nome);
    }

    /* ===== METAS ===== */
    public String metaResumoSemanal(int totalSemanal) {
        return String.format("Total semanal: %d. Confira o desempenho.", totalSemanal);
    }
    public String metaResumoMensal(int totalMensal) {
        return String.format("Total mensal: %d. Veja os resultados.", totalMensal);
    }
}
