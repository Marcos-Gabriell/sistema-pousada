package br.com.pousda.pousada.notificacoes.usuarios.application;

import br.com.pousda.pousada.notificacoes.application.NotificationService;
import br.com.pousda.pousada.notificacoes.application.Templates;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationOrigin;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class UsuarioNotifierImpl implements UsuarioNotifier {

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private final NotificationService notifications;
    private final Templates tpl;

    private String today() { return LocalDate.now(SP).toString(); }

    @Override
    public void criado(Long usuarioId, String nome, String email, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_CRIADO, "Usuário criado",
                tpl.usuarioCriado(nome, email), "/usuarios/" + usuarioId, "ABRIR_USUARIO", usuarioId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void atualizado(Long usuarioId, String nome, String campo, String de, String para, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_ATUALIZADO, "Usuário atualizado",
                tpl.usuarioAtualizado(nome, campo, de, para), "/usuarios/" + usuarioId, "ABRIR_USUARIO", usuarioId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void statusAlterado(Long usuarioId, String nome, String novoStatus, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_STATUS_ALTERADO, "Status de usuário alterado",
                tpl.usuarioStatusAlterado(nome, novoStatus), "/usuarios/" + usuarioId, "ABRIR_USUARIO", usuarioId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void senhaResetada(Long usuarioId, String nome, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_SENHA_RESETADA, "Senha resetada",
                tpl.usuarioSenhaResetada(nome), "/usuarios/" + usuarioId, "ABRIR_USUARIO", usuarioId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void autoExcluido(Long usuarioId, String nome, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_AUTO_EXCLUIDO, "Usuário auto-excluído",
                tpl.usuarioAutoExcluido(nome), "/usuarios", "VER_USUARIOS", usuarioId,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }

    @Override
    public void excluido(Long usuarioId, String nome, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_EXCLUIDO, "Usuário excluído",
                tpl.usuarioExcluido(nome), "/usuarios", "VER_USUARIOS", usuarioId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void atualizouProprioPerfil(Long usuarioId, String nome, String campo, String de, String para, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_ATUALIZOU_PROPRIO_PERFIL, "Perfil atualizado (pelo usuário)",
                tpl.usuarioAtualizouProprioPerfil(nome, campo, de, para), "/usuarios/" + usuarioId, "ABRIR_USUARIO", usuarioId,
                today(), usuarioId, null, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void senhaAtualizadaPeloProprio(Long usuarioId, String nome, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.USUARIO_SENHA_ATUALIZADA_PELO_PROPRIO, "Senha atualizada (pelo usuário)",
                tpl.usuarioSenhaAtualizadaPeloProprio(nome), "/usuarios/" + usuarioId, "ABRIR_USUARIO", usuarioId,
                today(), usuarioId, null, NotificationOrigin.USUARIO, destinatarios
        );
    }
}
