package br.com.pousda.pousada.notificacoes.infra.adapter;

import br.com.pousda.pousada.notificacoes.application.UsersQueryPort;
import br.com.pousda.pousada.usuarios.infra.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class UsersQueryAdapter implements UsersQueryPort {

    private final HttpServletRequest request;
    private final UsuarioRepository usuarioRepository;

    @Override
    public long currentUserId() {
        try {
            String raw = request.getHeader("X-User-Id");
            if (raw == null || raw.isBlank()) return 0L;
            return Long.parseLong(raw.trim());
        } catch (Exception e) {
            log.debug("Não foi possível resolver X-User-Id: {}", e.getMessage());
            return 0L;
        }
    }

    @Override
    public Set<Long> adminIds() {
        // Ajuste este método conforme sua modelagem de usuários/perfis:
        // aqui considero role "ADMIN"
        return usuarioRepository.findAll().stream()
                .filter(u -> "ADMIN".equalsIgnoreCase(u.getRole()))
                .map(u -> u.getId())
                .collect(Collectors.toSet());
    }
}
