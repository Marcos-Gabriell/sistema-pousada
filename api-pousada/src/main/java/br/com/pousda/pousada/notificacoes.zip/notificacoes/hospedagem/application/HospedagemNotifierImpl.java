package br.com.pousda.pousada.notificacoes.hospedagem.application;


import br.com.pousda.pousada.notificacoes.application.NotificationService;
import br.com.pousda.pousada.notificacoes.application.Templates;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationOrigin;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class HospedagemNotifierImpl implements HospedagemNotifier {

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private final NotificationService notifications;
    private final Templates tpl;

    private String today() { return LocalDate.now(SP).toString(); }

    @Override
    public void criada(Long hospedagemId, String hospede, String quarto, String checkin, String checkout,
                       Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.HOSPEDAGEM_CRIADA,
                "Hospedagem criada",
                tpl.hospedagemCriada(hospede, quarto, checkin, checkout),
                "/hospedagens/" + hospedagemId, "ABRIR_HOSPEDAGEM", hospedagemId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void atualizada(Long hospedagemId, String hospede, String campo, String de, String para,
                           Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.HOSPEDAGEM_ATUALIZADA,
                "Hospedagem atualizada",
                tpl.hospedagemAtualizada(hospede, campo, de, para),
                "/hospedagens/" + hospedagemId, "ABRIR_HOSPEDAGEM", hospedagemId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void checkoutLembrete11h(Long hospedagemId, String hospede, String quarto, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.HOSPEDAGEM_CHECKOUT_LEMBRETE_11H,
                "Lembrete: checkout às 11h",
                tpl.hospedagemCheckout11h(quarto, hospede),
                "/hospedagens/" + hospedagemId, "ABRIR_HOSPEDAGEM", hospedagemId,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }

    @Override
    public void alertaReservaAmanha(Long reservaId, String hospede, String quarto, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.HOSPEDAGEM_ALERTA_RESERVA_AMANHA,
                "Alerta: reserva amanhã",
                tpl.hospedagemAlertaReservaAmanha(hospede, quarto),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }
}
