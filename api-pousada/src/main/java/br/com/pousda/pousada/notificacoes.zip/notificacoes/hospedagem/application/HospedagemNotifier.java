package br.com.pousda.pousada.notificacoes.hospedagem.application;


import java.util.Set;

public interface HospedagemNotifier {
    void criada(Long hospedagemId, String hospede, String quarto, String checkin, String checkout,
                Long autorId, String autorJson, Set<Long> destinatarios);
    void atualizada(Long hospedagemId, String hospede, String campo, String de, String para,
                    Long autorId, String autorJson, Set<Long> destinatarios);
    void checkoutLembrete11h(Long hospedagemId, String hospede, String quarto, Set<Long> destinatarios);
    void alertaReservaAmanha(Long reservaId, String hospede, String quarto, Set<Long> destinatarios);
}
