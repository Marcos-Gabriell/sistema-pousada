package br.com.pousda.pousada.notificacoes.financeiro.application;

import java.util.Set;

public interface FinanceiroNotifier {
    void saidaCriada(Long saidaId, String motivo, Double valor,
                     Long autorId, String autorJson, Set<Long> destinatarios);

    void saidaAtualizada(Long saidaId, String deMotivo, Double deValor,
                         String paraMotivo, Double paraValor,
                         Long autorId, String autorJson, Set<Long> destinatarios);

    void saidaExcluida(Long saidaId, String motivo, Double valor,
                       Long autorId, String autorJson, Set<Long> destinatarios);
}
