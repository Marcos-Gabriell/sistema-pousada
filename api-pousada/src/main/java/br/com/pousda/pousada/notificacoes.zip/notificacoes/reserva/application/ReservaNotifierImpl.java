package br.com.pousda.pousada.notificacoes.reserva.application;


import br.com.pousda.pousada.notificacoes.application.NotificationService;
import br.com.pousda.pousada.notificacoes.application.Templates;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationOrigin;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ReservaNotifierImpl implements ReservaNotifier {

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private final NotificationService notifications;
    private final Templates tpl;

    private String today() { return LocalDate.now(SP).toString(); }

    @Override
    public void criada(Long reservaId, String codigo, String hospede, String quarto,
                       Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_CRIADA,
                "Nova reserva criada",
                tpl.reservaCriada(codigo, hospede, quarto),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void atualizada(Long reservaId, String codigo, String campo, String de, String para,
                           Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_ATUALIZADA,
                "Reserva atualizada",
                tpl.reservaAtualizada(codigo, campo, de, para),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void confirmada(Long reservaId, String codigo, String hospede,
                           Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_CONFIRMADA,
                "Reserva confirmada",
                tpl.reservaConfirmada(codigo, hospede),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void cancelada(Long reservaId, String codigo, String motivo,
                          Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_CANCELADA,
                "Reserva cancelada",
                tpl.reservaCancelada(codigo, motivo),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void resumoVespera(int qtd, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_RESUMO_VESPERA,
                "Resumo da véspera",
                tpl.reservaResumoVespera(qtd),
                "/reservas?filtro=amanha", "VER_RESERVAS", null,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }

    @Override
    public void hojePendente(int qtd, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_HOJE_PENDENTE,
                "Check-ins PENDENTES hoje",
                tpl.reservaHojePendente(qtd),
                "/reservas?filtro=hoje&status=PENDENTE", "VER_RESERVAS", null,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }

    @Override
    public void ultimaChamada(Long reservaId, String codigo, String hospede, String quarto, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_ULTIMA_CHAMADA,
                "Última chamada de confirmação",
                tpl.reservaUltimaChamada(codigo, hospede, quarto),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }

    @Override
    public void naoConfirmadaCancelada(Long reservaId, String codigo, String hospede, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.RESERVA_NAO_CONFIRMADA_CANCELADA,
                "Reserva cancelada por falta de confirmação",
                tpl.reservaNaoConfirmadaCancelada(codigo, hospede),
                "/reservas/" + reservaId, "ABRIR_RESERVA", reservaId,
                today(), null, null, NotificationOrigin.AUTOMATICO, destinatarios
        );
    }
}
