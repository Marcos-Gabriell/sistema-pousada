package br.com.pousda.pousada.notificacoes.core.domain.enums;


public enum NotificationStatus { NOVO, LIDO }
