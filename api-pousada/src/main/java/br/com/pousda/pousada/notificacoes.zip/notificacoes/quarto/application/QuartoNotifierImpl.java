package br.com.pousda.pousada.notificacoes.quarto.application;

import br.com.pousda.pousada.notificacoes.application.NotificationService;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationOrigin;
import br.com.pousda.pousada.notificacoes.core.domain.enums.NotificationType;
import br.com.pousda.pousada.quartos.domain.Quarto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class QuartoNotifierImpl implements QuartoNotifier {

    private static final ZoneId SP = ZoneId.of("America/Sao_Paulo");
    private final NotificationService notifications;

    private String today() { return LocalDate.now(SP).toString(); }
    private String n(Quarto q) { return q != null ? (q.getNumero() != null ? q.getNumero() : "-") : "-"; }
    private String nm(Quarto q){ return q != null ? (q.getNome()   != null ? q.getNome()   : "-") : "-"; }

    @Override
    public void criado(Quarto quarto, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.QUARTO_CRIADO,
                "Quarto criado",
                "Quarto " + n(quarto) + " (" + nm(quarto) + ") foi cadastrado.",
                "/quartos/" + quarto.getId(), "VER_QUARTO", quarto.getId(),
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void atualizado(Quarto quarto, String resumo, Long autorId, String autorJson, Set<Long> destinatarios) {
        String body = (resumo == null || resumo.isBlank())
                ? "Dados do quarto " + n(quarto) + " foram atualizados."
                : "Quarto " + n(quarto) + " atualizado • " + resumo;
        notifications.send(
                NotificationType.QUARTO_ATUALIZADO,
                "Quarto atualizado",
                body,
                "/quartos/" + quarto.getId(), "VER_QUARTO", quarto.getId(),
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void entrouManutencao(Quarto quarto, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.QUARTO_ENTROU_MANUTENCAO,
                "Quarto em manutenção",
                "Quarto " + n(quarto) + " entrou em manutenção.",
                "/quartos/" + quarto.getId(), "VER_QUARTO", quarto.getId(),
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void voltouDisponivel(Quarto quarto, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.QUARTO_VOLTOU_DISPONIVEL,
                "Quarto disponível",
                "Quarto " + n(quarto) + " voltou a ficar disponível.",
                "/quartos/" + quarto.getId(), "VER_QUARTO", quarto.getId(),
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }

    @Override
    public void excluido(Quarto quarto, Long autorId, String autorJson, Set<Long> destinatarios) {
        notifications.send(
                NotificationType.QUARTO_EXCLUIDO,
                "Quarto excluído",
                "Quarto " + n(quarto) + " (" + nm(quarto) + ") foi excluído.",
                "/quartos", "VER_QUARTOS", quarto.getId(),
                today(), autorId, autorJson, NotificationOrigin.USUARIO, destinatarios
        );
    }
}
